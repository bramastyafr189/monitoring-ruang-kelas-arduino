﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'it', {
	anchor: 'Ancora',
	flash: 'Animazione Flash',
	hiddenfield: 'Campo Nascosto',
	iframe: 'IFrame',
	unknown: 'Oggetto sconosciuto'
} );
